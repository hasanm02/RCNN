# OBJDataset > 2024-03-29 3:45pm
https://universe.roboflow.com/rcnn-wo7bm/objdataset

Provided by a Roboflow user
License: CC BY 4.0

